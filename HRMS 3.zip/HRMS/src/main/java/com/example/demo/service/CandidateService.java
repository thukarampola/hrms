package com.example.demo.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.bean.Candidate;
import com.example.demo.repository.CandidateRepository;

@Service
public class CandidateService {

	@Autowired
	private CandidateRepository candidateRepository;

//	public List<Candidate> saveCandidate(List<Candidate> candidate) {
//		return null;
//	}
	public List<Candidate> listAllCandidates() {
		return candidateRepository.findAll();
	}

	public Candidate saveCandidate(Candidate candidate) {
		if(candidate.getManager1()==null) {
			candidate.setStatus(0);
		}else {
			candidate.setStatus(1);
		}
		return candidateRepository.save(candidate);
	}

	public String approveStatus(boolean approve, Integer candId,String mgrId) throws Exception {
		Optional<Candidate> optionalCandidate = candidateRepository.findById(candId);
		Candidate candidate = null;
		if (!optionalCandidate.isPresent()) {
			throw new Exception("Candidate not available");
		}
		candidate = optionalCandidate.get();
		if(!approve) {
			candidate.setStatus(-1);
			return "Candidate status updated as rejected";
		}else if(approve) {
			
			if(candidate.getManager2()==null && candidate.getManager1ApprovedAt()==null) {
				candidate.setStatus(2);
				candidate.setManager2(mgrId);
				candidate.setManager1ApprovedAt(new Date(System.currentTimeMillis()));
			}else if(candidate.getManager3()==null && candidate.getManager2ApprovedAt()==null) {
				candidate.setStatus(3);
				candidate.setManager3(mgrId);
				candidate.setManager2ApprovedAt(new Date(System.currentTimeMillis()));
			}else if(candidate.getManager4()==null && candidate.getManager3ApprovedAt()==null) {
				candidate.setStatus(4);
				candidate.setManager4(mgrId);
				candidate.setManager3ApprovedAt(new Date(System.currentTimeMillis()));
			}else {
				candidate.setStatus(5);
				candidate.setManager4ApprovedAt(new Date(System.currentTimeMillis()));
			}
		}
		return "Candidate status updated";
	}
}
