package com.example.demo.controller;

import java.util.List;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.bean.Candidate;
import com.example.demo.service.CandidateService;

@RestController
public class CandidateController {
	@Autowired
	private CandidateService candidateService;

	@GetMapping("/getAllCandidates")
	public ResponseEntity<List<Candidate>> getAllCandidates() {
		return new ResponseEntity<List<Candidate>>(candidateService.listAllCandidates(), HttpStatus.OK);
	}

	@PostMapping("/saveCandidate")
	public ResponseEntity<Candidate> saveCandidate(@RequestBody Candidate candidate) {
		return new ResponseEntity<Candidate>(candidateService.saveCandidate(candidate), HttpStatus.OK);
	}

	@PutMapping("/approveCandidate")
	public ResponseEntity<String> approveCandidate(@RequestParam(value = "approve") boolean approve,
			@RequestParam(value = "candId") Integer candId, @RequestParam(value = "mgrId") Integer mgrId) {
		return null;
	}

}
