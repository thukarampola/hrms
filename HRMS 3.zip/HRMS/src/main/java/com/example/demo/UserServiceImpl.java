package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl {

	@Autowired
	private UserRepo repo;
	
	public User saveUser(User user) {
	
		return repo.save(user); 
	}
	
	public List<User> listUsers(){
		return repo.findAll();
	}
	
	public User getUser(Integer id) {
		return repo.findById(id).get();
	}
}
