package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TestController {

	@Autowired
	private UserServiceImpl service;

	@PostMapping("/saveUser")
	public User saveUser(@RequestBody User user) {
		return service.saveUser(user);

	}

	@GetMapping("/getAllUsers")
	public List<User> getAllUsers() {
		return service.listUsers();
	}

	@GetMapping("/getUser/{}")
	public User getUserById(@PathVariable Integer id) {
		return service.getUser(id);
	}

}
