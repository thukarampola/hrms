package com.example.demo.reponse;

public class ExceptionResponse {

}
