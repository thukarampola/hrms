package com.example.demo.bean;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

@Entity
public class Candidate {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer candidateId;
	@NotEmpty
	private String firstName;
	private String lastName;
	@NotEmpty(message = "Check the phone number.")
	private long phoneNumber;
	@Email(message = "Enter the valid email id.")
	private String emailId;
	
	private String skills;
	@NotEmpty
	private String primarySkills;
	@NotEmpty
	private String slectedLocation;
	@NotEmpty
	private String noticePeriodInDays;
	@NotEmpty
	private double currentCTC;
	@NotEmpty
	private double expectedCTC;
	@NotEmpty
	private double offeredCTC;
	private float hikePercentage;
	private int status;
	@NotEmpty
	private String stream;
	private String currentDesignation;
	@NotEmpty
	private String hiringManager;
	@NotEmpty
	private double minBudget;
	@NotEmpty
	private double maxBudget;
	
	private String tower;
	@NotEmpty
	private String subTower;
	@NotEmpty
	private Date dateOfJoining;
	@NotEmpty
	private String skillCategory;
	@NotEmpty
	private String legatoDesignation;
	@NotEmpty
	private String jobCode;
	private String notes;
	@NotEmpty
	private Integer hrExec;
	@CreatedDate
	private Date createdAt;
	@LastModifiedDate
	private Date updatedAt;
	private String manager1;
	private Date manager1ApprovedAt;
	private String manager2;
	private Date manager2ApprovedAt;
	private String manager3;
	private Date manager3ApprovedAt;
	private String manager4;
	private Date manager4ApprovedAt;

	public String getManager1() {
		return manager1;
	}

	public Integer getHrExec() {
		return hrExec;
	}

	public void setHrExec(Integer hrExec) {
		this.hrExec = hrExec;
	}

	public void setManager1(String manager1) {
		this.manager1 = manager1;
	}

	public Date getManager1ApprovedAt() {
		return manager1ApprovedAt;
	}

	public void setManager1ApprovedAt(Date manager1ApprovedAt) {
		this.manager1ApprovedAt = manager1ApprovedAt;
	}

	public String getManager2() {
		return manager2;
	}

	public void setManager2(String manager2) {
		this.manager2 = manager2;
	}

	public Date getManager2ApprovedAt() {
		return manager2ApprovedAt;
	}

	public void setManager2ApprovedAt(Date manager2ApprovedAt) {
		this.manager2ApprovedAt = manager2ApprovedAt;
	}

	public String getManager3() {
		return manager3;
	}

	public void setManager3(String manager3) {
		this.manager3 = manager3;
	}

	public Date getManager3ApprovedAt() {
		return manager3ApprovedAt;
	}

	public void setManager3ApprovedAt(Date manager3ApprovedAt) {
		this.manager3ApprovedAt = manager3ApprovedAt;
	}

	public String getManager4() {
		return manager4;
	}

	public void setManager4(String manager4) {
		this.manager4 = manager4;
	}

	public Date getManager4ApprovedAt() {
		return manager4ApprovedAt;
	}

	public void setManager4ApprovedAt(Date manager4ApprovedAt) {
		this.manager4ApprovedAt = manager4ApprovedAt;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Date getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public Integer getCandidateId() {
		return candidateId;
	}

	public void setCandidateId(Integer candidateId) {
		this.candidateId = candidateId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public long getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getSkills() {
		return skills;
	}

	public void setSkills(String skills) {
		this.skills = skills;
	}

	public String getPrimarySkills() {
		return primarySkills;
	}

	public void setPrimarySkills(String primarySkills) {
		this.primarySkills = primarySkills;
	}

	public String getSlectedLocation() {
		return slectedLocation;
	}

	public void setSlectedLocation(String slectedLocation) {
		this.slectedLocation = slectedLocation;
	}

	public String getNoticePeriodInDays() {
		return noticePeriodInDays;
	}

	public void setNoticePeriodInDays(String noticePeriodInDays) {
		this.noticePeriodInDays = noticePeriodInDays;
	}

	public double getCurrentCTC() {
		return currentCTC;
	}

	public void setCurrentCTC(double currentCTC) {
		this.currentCTC = currentCTC;
	}

	public double getExpectedCTC() {
		return expectedCTC;
	}

	public void setExpectedCTC(double expectedCTC) {
		this.expectedCTC = expectedCTC;
	}

	public double getOfferedCTC() {
		return offeredCTC;
	}

	public void setOfferedCTC(double offeredCTC) {
		this.offeredCTC = offeredCTC;
	}

	public float getHikePercentage() {
		return hikePercentage;
	}

	public void setHikePercentage(float hikePercentage) {
		this.hikePercentage = hikePercentage;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getStream() {
		return stream;
	}

	public void setStream(String stream) {
		this.stream = stream;
	}

	public String getCurrentDesignation() {
		return currentDesignation;
	}

	public void setCurrentDesignation(String currentDesignation) {
		this.currentDesignation = currentDesignation;
	}

	public String getHiringManager() {
		return hiringManager;
	}

	public void setHiringManager(String hiringManager) {
		this.hiringManager = hiringManager;
	}

	public double getMinBudget() {
		return minBudget;
	}

	public void setMinBudget(double minBudget) {
		this.minBudget = minBudget;
	}

	public double getMaxBudget() {
		return maxBudget;
	}

	public void setMaxBudget(double maxBudget) {
		this.maxBudget = maxBudget;
	}

	public String getTower() {
		return tower;
	}

	public void setTower(String tower) {
		this.tower = tower;
	}

	public String getSubTower() {
		return subTower;
	}

	public void setSubTower(String subTower) {
		this.subTower = subTower;
	}

	public Date getDateOfJoining() {
		return dateOfJoining;
	}

	public void setDateOfJoining(Date dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}

	public String getSkillCategory() {
		return skillCategory;
	}

	public void setSkillCategory(String skillCategory) {
		this.skillCategory = skillCategory;
	}

	public String getLegatoDesignation() {
		return legatoDesignation;
	}

	public void setLegatoDesignation(String legatoDesignation) {
		this.legatoDesignation = legatoDesignation;
	}

	public String getJobCode() {
		return jobCode;
	}

	public void setJobCode(String jobCode) {
		this.jobCode = jobCode;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

}
